//import React from "react";
import * as React from "react";
import ProductList from "../components/ProductList";
import "../components/ProductList.css";

function Products() {
  return (
    <div className="products">
      <ProductList />
    </div>
  );
}

export default Products;
