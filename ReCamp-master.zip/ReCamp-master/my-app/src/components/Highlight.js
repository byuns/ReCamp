import React, { useState } from "react";
import { data } from "./HashtagData";
import { Reviewdata } from "./Reviewdata";

const Highlight = (word) => {
  return;
};

export default Highlight;
