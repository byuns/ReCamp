import React from "react";
import styled from "styled-components";
import { Reviewdata } from "./Reviewdata";
import { useState, useEffect } from "react";

const SortOption = ({ posts }) => {
  return <div></div>;
};

export default SortOption;
